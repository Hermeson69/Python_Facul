import datetime
from Sistema.sistema import SistemaFarmacia


def main():
    sistema = SistemaFarmacia()
    sistema.menu_interativo()
    

if __name__ == "__main__":
    main()